# Session 1

![0.mwp71v173u](images/0.mwp71v173u)

----
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

>Welcome Everyone!
>
<br>
<br>
<br>
<br>
<br>
<br>

**Perface? Sort of!**
1. We received staggering 660+ application for this EIP
2. Finally we have 445 EInterns, split into 7 Batches
3. Professional vs Student ratio is not 85+%!
4. People from your batch are from - DxC Technology - First American, Freelancer, Ernst & Young, Thorogood Associates, IISc, Neustar, KNAB FInance, Accenture, Sigtuple, Mahindra Electric Mobility Ltd., Moody's Analytics, Skillspeed, Cognizant Technology Solutions, Bsharp Sales Enabler, Jifflenow, NVIDIA, Amazon, Kint, IBM, CMR, IIIT, InGene Dynamics, Alten Calsoft Labs, Porter, Geekskool, SAP Labs, Tharsha Ventures, Touchkin, Analytics Quotient, Microchip, Unisys, HP, TCS, IMS Health, Reflik, 3 Frames Lab, Velotio Technologies, Mu Sigma, Capgemini, KNOWLEDGEHUT, HCL, NVIDIA, etc.
5. We are really proud of what we are trying to achieve here today!

![0.t6mbfb2y7rj](images/0.t6mbfb2y7rj)

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

**Administrative Stuff:**
1. Make sure you have a Google Colab Account
2. Make sure you are there on main WhatsApp group. Please keep this group "Mute" as people are posting random stuff. 
3. Please join our Discourse forum, hosted at mlblr.com/discourse to discuss about topics 

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

### External Internship Program 

1. We have 2 hours of 10 session, spread over 40-50 days
2. 2 hours per session is really too less to become a master. 
3. Our aim is to get you started, covering the fundamentals. Unless you spend at least 3-4 hours on your own reading-doing stuff, this program would fail for you. 
4. Assignments are designed to this specific purpose. Since 87.5% are from industry, there might be some resistance to become a student again, but let's try!
4. Our relation with you is "Driving Instructor - New Driver" and not of "Professor - Student". This means our focus is on to help you drive the car, not to understand it's internal fundamentals (a rule we will break many times). 
5. If the batch is running slow, we will cover lesser content in 10 sessions, instead of rushing through everything. 

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

## Let's get started


<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

> This is how we want you to feel after the 10 sessions
> 
![PUNCH](http://teamjimmyjoe.com/wp-content/uploads/2017/02/funny-Little-Kim-Jong-un.gif)


<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

### Building the Intuition!

<br>
<br>

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

<br>
<br>
<br>
<br>
<br>
<br>

##### OUR BRAIN
![firing](https://media.giphy.com/media/rUtDCuiPlFE52/giphy-downsized-large.gif)

> An ultra dense connected network of flowing information


<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

## EYES

![eye](https://i.pinimg.com/originals/06/7b/3b/067b3baae3260fef5fbe8bae7462a3f8.jpg)

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

![image](http://3.bp.blogspot.com/-Elau01j_Uy8/VnWucwCsm_I/AAAAAAAALEs/03zy4R_sAoI/s1600/CrossSection.JPG =500x)

>Light to Neurons

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

![cells](https://www.micronaut.ch/wp-content/uploads/2012/12/%C2%A9-Micronaut-Human-Retina-006364.jpg)


<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
>This is where image to RGB/GrayScale convesion ends!
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

## BORED CAT EXPERIMENT

![bored cat](http://gif-finder.com/wp-content/uploads/2015/12/Bored-cat.gif =500x)

![bored cat2](https://media.giphy.com/media/5gUnOrltPvZzW/giphy.gif)
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>


![red](http://fourier.eng.hmc.edu/e180/lectures/figures/retinotopicmap.gif)
> Radioactive Glucose
> 



<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

Retinotopic Map

![map](https://www.researchgate.net/profile/Daniel_Simons2/publication/7994860/figure/fig3/AS:279070249111558@1443546940146/Subcortical-visual-pathwayConverging-neuroscientific-evidence-indicates-that-there-is-a.png =400x)

![cortical magnification](http://www.cns.nyu.edu/~david/courses/perception/lecturenotes/V1/LGN-V1-slides/Slide12.jpg =500x)

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

Edge Detection
![poorcat](http://www.utdallas.edu/~tres/integ/sen4/8_05.jpg =300x)


<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>


## Coretex Processing

![cortex](http://bethycotter.wdfiles.com/local--files/introducingtheeye/Screen%20Shot%202012-08-24%20at%2011.36.20%20PM.png =600x)

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>


![image.gif](images/image.gif)
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

![detailed](https://www.frontiersin.org/files/Articles/34845/fpsyg-04-00124-HTML/image_m/fpsyg-04-00124-g001.jpg =400x)

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>


_____

# Back to Neural Computing

We need feature extraction methods and then combining methods

![one](http://aishack.in/static/img/tut/conv-line-detection-horizontal-result.jpg =200x)
![two](http://aishack.in/static/img/tut/conv-edge-detection-result.jpg =200x)
![three](http://aishack.in/static/img/tut/conv-sobel-result.png =200x)
![four](http://aishack.in/static/img/tut/conv-laplacian-result.png =200x)

Let's look at some code. 

# Welcome Convolution - Feature Extraction
![image](https://ujwlkarn.files.wordpress.com/2016/08/giphy.gif =400x)

## Combining these concepts
![image](https://ujwlkarn.files.wordpress.com/2016/08/conv_all.png =500x)

Closer Look

![image](https://ujwlkarn.files.wordpress.com/2016/08/screen-shot-2016-08-06-at-12-45-35-pm.png =500x)

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

# Concepts

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

## What is convolution?

![4-2ConvolutionSmall.gif](images/4-2ConvolutionSmall.gif)




## input(28x28x1)
## Conv2D(32, 3, 3, act=ReLU) >?
## MaxPooling(2) >?
## Activation (ReLU) << Useless here. 
## Conv2D(10, 1, 1, act=ReLU) Perfectly OK
## Conv2D(10, 13, 13, act=None) >?
## SoftMax()
## Compile/Fit/Optimize
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

## What do we gain and what do we lose?

![5-3 Convolution Small.gif](images/5-3 Convolution Small.gif)


<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

## Why do we add layers? 

![Receptive Field Small.gif](images/Receptive Field Small.gif)


<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

## How many layers would we need to move from 400x400 image to 100 numbers? 


<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

## MaxPooling (about to get obsolete)

![MaxPool Small.gif](images/MaxPool Small.gif)


<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

## Let's build a network!
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>



## 3x3 is a lie! How convolution actually works? 

![convolution.gif](images/convolution.gif)
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

## The reason for dimensional reductionality!

But what about z (or channels)?
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

## Welcome to 1x1 convolution?

![1x1 2.png](images/1x1 2.png)

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

## Let's see some animation. 


![1x1 convolution.png](images/1x1 convolution.png)
## Let's build the network again!
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

## What happens when we train a network? 

This is what happens over a period of time to our neurons/kernels/filters
![image](https://camo.githubusercontent.com/33c848b845290ce25497d00a6e3f1a3d02216772/687474703a2f2f6172732d6173687568612e72752f7064662f766473646e6e2f636f6e762e676966)
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

# Let's look at the code:

```python
 
model.add(Convolution2D(32, 3, 3, activation='relu', input_shape=(28,28,1)))
model.add(Convolution2D(10, 1, activation='relu'))
model.add(Convolution2D(10, 26))
model.add(Flatten())
model.add(Activation('softmax'))
```
# bit.ly/2IBqQJD


<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

# Story of Harry Potter

> I didn't read the book!
> 

Character | Age 
--- | ---
Harry | 28
Me | 24 :D
You | 30 XD

![](https://www.irishtimes.com/polopoly_fs/1.3170107.1501253408!/image/image.jpg_gen/derivatives/box_620_330/image.jpg =300x)

$x_2^2 = f(Harry)$
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

# ASSIGNMENT 1

* Download Boostnote (or any markdown editor you prefer)
* You can refer this link to learn about markdown: [Markdown Cheatsheet](https://github.com/adam-p/markdown-here/wiki/Markdown-Cheatsheet)
* Write 2 articles between 100-200 words in markdown and email back your file in this format **FIRSTNAME_BATCH_X_ASSIGNMENT1.md** 
* You must mention your name, batch number in your markdown file. 
* Your markdown file must have an image of your choice. 
* You can pick any 2 from these topics:
  * Convolution
  * Filters/Kernels
  * Epochs
  * 1x1 convolution
  * 3x3 convolution
  * Feature Maps
  * Feature Engineering
* Bonus points if you write on any of these:
  * Activation Function
  * How to create an account on GitHub and upload a sample project
  * Receptive Field. 
  * 10 examples of use of MathJax in Markdown
* Deadline Tuesday 11:30PM
* You **MUST** use your own words while writing any of the above, if we find plagiarism, 0 marks would be awarded for that article. 